/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fadil;

/**
 *
 * @author dell
 */
public class Fadil {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Fadil per = new Fadil(); 
        System.out.println("====Variable====");
        per.perVariable();
        System.out.println("====Perbandingan====");
        per.perPercabanganIf();
        System.out.println("====NILAI====");
        per.perPercabanganIf();
        System.out.println("===LAMPU====");
        per.perPercabanganSwitch();
        
    }
        
  void perVariable(){
      System.out.println("-----Biodata-----");
String nama_depan, namaBelakang, alamat;
        int npm, umur, noHp;
//  isi variable
        nama_depan = "Mufadhil";
        namaBelakang = "Arrahman";
        alamat = "Padang";
        umur = 20;
        npm = 19100067;
        noHp =813638272;
//  cetak
        System.out.println("Nama   : " + nama_depan +" "+namaBelakang);
        System.out.println("Alamat : " + alamat);
        System.out.println("NPM    : " + npm);
        System.out.println("No Hp  : " + noHp);
        System.out.println("Umur   : " + umur);
   }
  
  void perPercabanganIf(){
  int belanja = 150000;
 
// mengambil input 
      System.out.println("Total Belanjaan Rp : "+ belanja +" ");
      
// percabangan if dengan nominal 150000
      if (belanja >=150000){
          System.out.println("selamat anda mendapatkan hadiah");
      }
      
      System.out.println("terima kasih telah belanja di toko kami");
 
 }
   void perPercabanganIF(){
        int nilai;
        String grade;
//      mengambil input
       System.out.println("inputkan nilai");
       nilai= 81;
//      hitung gradenya
     if (nilai > 90 && nilai < =100){
         grade = "A";
     }else if (nilai > 80 && nilai <=90){
         grade = "B+"; 
     }else if (nilai > 70 && nilai <=80){
         grade = "B"; 
     }else if (nilai > 60 && nilai <=70){
         grade = "C+"; 
     }else if (nilai > 50 && nilai <=60){
         grade = "C"; 
     }else if (nilai > 40 && nilai <=50){
         grade = "D"; 
     }else {
     grade = "E";
     }
// cetak hasilnya
       System.out.println("grade:"+ grade);
      
}

   void perPercabanganSwitch(){
       String lampu;
 
// mengambil input
       System.out.println("inputkan nama warna");
       lampu = "hijau";
       
       switch (lampu){
         case"merah";
             System.out.println("lampu merah,berhenti");
             break;
         case"kuning";
             System.out.println("lampu kuning,harap hati-hati");
             break;
         case"hijau";
             System.out.println("lampu hijau,jalan");
             break;
         default:
             System.out.println("warna lampu salah");
       }
   }
}
    }
    
}
